import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'statistics.dart';

class mainscreen extends StatelessWidget {
  var preventiontext = ['Hand Sanitiser', 'Keep Distance', 'Stay Home', 'Wash Hands', 'Wear your Mask'];
  var symptomtext = ['Cough','Fatigue','Fever','Shortness Breath','Sore Throat'];

  List<String> preventionimages = [
    "assets/images/handSanitiser.jpg",
    "assets/images/keepDistance.jpg",
    "assets/images/stayHome.jpg",
    "assets/images/washHands.jpg",
    "assets/images/wearMask.jpg"
  ];

  List<String> symptomimages = [
    "assets/images/cough.jpg",
    "assets/images/fatigue.jpg",
    "assets/images/fever.jpg",
    "assets/images/shortnessBreath.jpg",
    "assets/images/soreThroat.jpg"
  ];

  Widget customcard(
      String text, String imagepath, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(children: [
        Card(
          elevation: 10.0, //η σκια της καρτας
          child: Container(
            child: Wrap(
              children: [
                Image.network(imagepath,
                    height: 100, alignment: Alignment.center),
              ],
            ),
          ),
        ),
        ListTile(
          title: Text(text, textAlign: TextAlign.center),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Covid 19"),
        ),
        body: SizedBox(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: ListView(
              children: [
                Container(
                  child: const Padding(
                    padding: EdgeInsets.all(10),
                    child: Text(
                      "Symptoms of Covid 19",
                      textAlign: TextAlign.left,
                      style: TextStyle(fontSize: 35),
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 20.0),
                  height: 200.0,
                  child: ScrollConfiguration(
                    behavior: ScrollConfiguration.of(context).copyWith( //οριζοντια κυλιση
                        dragDevices: {
                          PointerDeviceKind.touch,
                          PointerDeviceKind.mouse
                        }),
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      children: <Widget>[
                        Container(
                          width: 160,
                          child: customcard(
                              symptomtext[0], symptomimages[0], context),
                        ),
                        Container(
                          width: 160,
                          child: customcard(
                              symptomtext[1], symptomimages[1], context),
                        ),
                        Container(
                          width: 160,
                          child: customcard(
                              symptomtext[2], symptomimages[2], context),
                        ),
                        Container(
                          width: 160,
                          child: customcard(
                              symptomtext[3], symptomimages[3], context),
                        ),
                        Container(
                          width: 160,
                          child: customcard(
                              symptomtext[4], symptomimages[4], context),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  width: 160,
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => statistics()));
                    },
                    child: customcard(
                        'Overview', 'assets/images/map.png', context),
                  ),
                ),
                Container(
                  child: const Padding(
                    padding: EdgeInsets.all(10),
                    child: Text(
                      "Prevention",
                      textAlign: TextAlign.left,
                      style: TextStyle(fontSize: 35),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 20.0),
                  height: 300.0,
                  child: ScrollConfiguration(
                    behavior: ScrollConfiguration.of(context).copyWith(
                        dragDevices: {
                          PointerDeviceKind.touch,
                          PointerDeviceKind.mouse
                        }),
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: <Widget>[
                        Container(
                          width: 160,
                          child: customcard(preventiontext[0], preventionimages[0],
                              context),
                        ),
                        Container(
                          width: 160,
                          child: customcard(preventiontext[1], preventionimages[1],
                              context),
                        ),
                        Container(
                          width: 160,
                          child: customcard(preventiontext[2], preventionimages[2],
                              context),
                        ),
                        Container(
                          width: 160,
                          child: customcard(preventiontext[3], preventionimages[3],
                              context),
                        ),
                        Container(
                          width: 160,
                          child: customcard(preventiontext[4], preventionimages[4],
                              context),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            )));
  }
}
