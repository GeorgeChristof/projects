
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';

class statistics extends StatelessWidget {

var genders = ['MALE', 'FEMALE'];
var cases = [0.336 , 0.113];

Widget statisticscard(
      String gender, double cases) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child:Align(
        alignment: Alignment.topCenter,
        child: Container(
          height: 150,
          decoration: const BoxDecoration(color: Colors.red),
          child: InkWell(
            child: Card(
              elevation: 10.0, //η σκια που θελουμε να φαινεται
              child: Wrap(
                children: [
                  ListTile(
                    title: Text(gender),
                    subtitle: const Text("Confirmed Cases"),
                  ),
                  Container(
                    child:
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: Text(
                          (cases*100).toString() + '%',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 30,
                            color: Colors.green
                          ),
                          )
                      ,) 
                  )
                ],
              ),
            ),
          )
        ),
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Statistics"),
        ),
        body: Container(
          decoration: const BoxDecoration(
                color: Colors.grey,
              ),
          child: Column(
          children: [
            Container(
              child: const Text(
                "Global Cases of Covid 19",
                style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
              ),
              
            ),
            Container(
              margin: const EdgeInsets.symmetric(vertical: 20.0),
              height: 300.0,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: <Widget>[
                  Container(
                    width: 250,
                    child: statisticscard(
                        genders[0],cases[0]),
                  ),
                  Container(
                    width: 250,
                    child: statisticscard(genders[1],cases[1]),
                  ),
                ],
              ),
            ),
          ],
        ),
      )        
    );
  }
}
