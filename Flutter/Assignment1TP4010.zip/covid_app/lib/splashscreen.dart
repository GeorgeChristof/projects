import 'package:flutter/material.dart';
import 'main.dart';
import 'mainscreen.dart';

class MyAppState extends State<MyApp> {

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        
        body: Container(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end, //βαζω το κουμπι στο κατω μερος
              children: [
                ElevatedButton(
                    child: const Text('Get Started'),
                    onPressed: ()=> {Navigator.push(context, MaterialPageRoute(builder: (context)=>mainscreen()))},
                    style: ElevatedButton.styleFrom(
                    primary: Colors.grey, //χρωμα κουμπιου
                    onPrimary: Colors.white), //χρωμα κειμενου κουμπιου
              ),
              const Padding(padding: EdgeInsets.all(30)), //κανω padding για να μην ειναι κολλημενο το κουμπι στο κατω μερος
              ],
            ),
          ),
          decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage('images/intro.jpg'), fit: BoxFit.cover),
          ),
        ),
    );
  }
}