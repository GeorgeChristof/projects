// ignore_for_file: file_names
import 'package:flutter/material.dart';
import 'package:assignment3/helpers/db_helpers.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({ Key? key }) : super(key: key);

  Future<List<Text>> getDemog() async {
    List<Text> people = [];
    Future<List<Map<String, dynamic>>> users = DBHelper.getData("users");
            await users.then((value) => {
              value.forEach((element) {
                people.add(Text("${element['name']} ${element['surname']} ${element['weight']} ${element['email']}"));
                })
              }
              );
              return people;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: FutureBuilder<List<Text>>(
        future: getDemog(),
        builder: (BuildContext context, AsyncSnapshot<List<Text>> people){
          if(people.hasData && people.data != null){
            return ListView(
              children: (people.data as List<Text>
            ));
          }
          else {
            return const Text('Null');
          }
        }
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
    children: [
      const DrawerHeader(
        decoration: BoxDecoration(
          color: Colors.blue,
        ),
        child: Text('Menu',
        style: TextStyle(fontSize: 35),),
      ),
      ListTile(
        title: const Text('Demographics'),
        onTap: () {

        },
      ),
    ],
        ),
      ),
    );
  }
}