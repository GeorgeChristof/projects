// ignore_for_file: use_key_in_widget_constructors, file_names

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:assignment3/helpers/db_helpers.dart';

class SignUpScreen extends StatelessWidget {

  Map<String,String> userData = <String,String>{};

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: body(context),
    );
  }

  final _formKey = GlobalKey<FormState>();
  final _passwordController = TextEditingController();
 
  Widget body(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('SignUpScreen'),
        leading: IconButton(icon:Icon(Icons.arrow_back),
        onPressed: () => Navigator.pop(context,false),),
      ),
      body: Center(
        //mainAxisAlignment: MainAxisAlignment.center,
        //children: [
          child: 
          Form(
            key: _formKey,
            autovalidateMode: AutovalidateMode.onUserInteraction,
            child:
            ListView(
              shrinkWrap: true,
              padding: EdgeInsets.all(10),
              children: 
                _buildForm(context),
              
            )
         ),
        ),
    );
  }

  DateTime selectedDate = DateTime.now();

List<Widget> _buildForm(BuildContext context) {
    return [
      
          Padding(                                        //Name
            padding: const EdgeInsets.all(0.0),
            child: TextFormField(
              validator: (value) {
                if (value != null && value.length <= 3) {
                  return 'Name cannot be empty or less than 3 char';
                } 
                return null;
              },
              onChanged: (value) => {userData["name"] = value},
              decoration: InputDecoration(
                labelText: 'Name',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
          Padding(                                      //Surname
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              validator: (value) {
                if (value != null && value.length <= 3) {
                  return 'Surname cannot be empty or less than 3 char';
                } 
                return null;
              },
              onChanged: (value) => {userData["surname"] = value},
              decoration: InputDecoration(
                labelText: 'Surname',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
          Padding(                                      //DATE
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [            
            ElevatedButton(
              onPressed: () {
                DatePicker.showDatePicker(context,
                      showTitleActions: true,
                      minTime: DateTime(1980, 1, 1),
                      maxTime: DateTime(2020, 12, 31),
                      theme: const DatePickerTheme(
                          headerColor: Colors.orange,
                          backgroundColor: Colors.black,
                          itemStyle: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18),
                          doneStyle:
                              TextStyle(color: Colors.white, fontSize: 16)),
                      onChanged: (date) {
                        userData["bdate"] = date.toString();
                    print('change $date in time zone ' +
                        date.timeZoneOffset.inHours.toString());
                  }, onConfirm: (date) {
                    print('confirm $date');
                  }, currentTime: DateTime.now(), locale: LocaleType.en);
                },
                child: Text(
                  selectedDate.toString(),
                  style: TextStyle(color: Colors.blue.shade50),
                )),
          ],),
        ),
          Padding(                                    //Gender
            padding: const EdgeInsets.all(8.0),
            child: DropdownButtonFormField<String>(
              items: <String>['Male','Female','Do not want to declare'].map((String value){
                return DropdownMenuItem<String>(value: value,child: Text(value),);
              }).toList(),
              onChanged: (value) => {userData["gender"] = value.toString()},
              decoration: InputDecoration(
                hintText: 'Gender',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
          Padding(                                        //Weight
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly
              ],
              keyboardType: TextInputType.number,
              onChanged: (value) => {userData["weight"] = value.toString()},
              decoration: InputDecoration(
                labelText: 'Weight',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
          Padding(                                      //Username
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              validator: (value) {
                if (value == null) {
                  return 'Username cannot be empty';
                } else if (value.length < 3) {
                  return 'Username must be at least 3 characters long.';
                }
                return null;
              },
              onChanged: (value) => {userData["username"] = value},
              decoration: InputDecoration(
                labelText: 'Username',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
          Padding(                              //Password
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              obscureText: true,
              controller: _passwordController,
              validator: (value) {
                if (value == null) {
                  return 'Password cannot be empty';
                } else if (value.length < 6) {
                  return 'Password must be at least 6 characters long.';
                }
                return null;
              },
              onChanged: (value) => {userData["password"] = value},
              decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
          Padding(                              //Email
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              validator: (value) {
                if(value != null){
                  bool hasOneAt = '@'.allMatches(value).length == 1;
                  bool hasOneDot = '.'.allMatches(value).length == 1;
                  if(hasOneAt == false ) return "Email missing @";
                  if(hasOneDot == false ) return "Email missing .";
                }
                
                return null;
              },
              onChanged: (value) => {userData["email"] = value},
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
        TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.blue.shade900
        ),
        onPressed: () {
          if (_formKey.currentState!.validate()) {
            DBHelper.insert("users", userData);
            debugPrint('All validations passed!');
            Navigator.of(context).pop();
          }
        },
        child:const Text(
          'Submit',
          style: TextStyle(
            fontSize: 20, 
            color: Colors.white
          ),
          ),
      ),
        ];
  }
}