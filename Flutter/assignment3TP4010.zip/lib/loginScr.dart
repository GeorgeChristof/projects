// ignore_for_file: file_names, use_key_in_widget_constructors

import 'package:assignment3/helpers/db_helpers.dart';
import 'package:flutter/material.dart';

class LoginScr extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: body(context),
    );
  }

  String username = "";
  String password = "";

  final _formKey = GlobalKey<FormState>();
  final _passwordController = TextEditingController();

  Widget body(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: [
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 70),
          child: Text(
            'Sign in', 
            style: TextStyle(
              fontSize: 35
              ),
              ),
        ),
        _buildForm(),
        const SizedBox(height: 10,),
      TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.blue.shade900
        ),
        onPressed: () {
          if (_formKey.currentState!.validate()) {
            Future<List<Map<String, dynamic>>> users = DBHelper.getData("users");
            users.then((value) => {
              value.forEach((element) {
                if(element["username"] == username) {
                  if(element["password"] == password){
                    Navigator.of(context).pushNamed('/homeScr');
                  }
                }
              }
              ),              
            });
          }
        },
        child:const Text(
          'Sign in',
          style: TextStyle(
            fontSize: 20, 
            color: Colors.white
          ),
          ),
      ),
      const SizedBox(height: 2),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          const Text("Don't have an account?"),
          GestureDetector(
            onTap: () {Navigator.of(context).pushNamed('/signupScr');},
            child: const Text(
              'Sign up',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          )
        ],
      )
      ])
    );
  }

  Form _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              onChanged: (value) => {username = value},
              validator: (value) {
                if (value == null) {
                  return 'Username cannot be empty';
                } else if (value.length < 3) {
                  return 'Username must be at least 3 characters long.';
                }
                return null;
              },
              decoration: InputDecoration(
                labelText: 'Username',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              onChanged: (value) => {password = value},
              obscureText: true,
              controller: _passwordController,
              validator: (value) {
                if (value == null) {
                  return 'Password cannot be empty';
                } else if (value.length < 6) {
                  return 'Password must be at least 6 characters long.';
                }
                return null;
              },
              decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}