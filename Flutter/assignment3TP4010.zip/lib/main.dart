import 'package:assignment3/homeScr.dart';
import 'package:assignment3/signupScr.dart';
import 'package:flutter/material.dart';
import './loginScr.dart';


void main() {
  runApp(MaterialApp(
    initialRoute: '/loginScr',
    routes: {
      '/loginScr': (context) => LoginScr(),
      '/signupScr': (context) => SignUpScreen(),
      '/homeScr': (context) => const HomeScreen(),
    },
  ));
}