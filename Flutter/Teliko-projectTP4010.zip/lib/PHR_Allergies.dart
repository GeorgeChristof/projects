// ignore_for_file: file_names

import 'helpers/db_helpers.dart';
import 'package:flutter/material.dart';

class Allergies extends StatelessWidget {
  const Allergies({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Allergies'),
        ),
        body: Column(
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/PHR_addAllergy');
              },
              child: const Text('Add Allergy'),
            ),
            getAllergies(),
          ],
        ));
  }

  Widget getAllergies() {
    return FutureBuilder(
        future: DBHelper.getData('allergies'),
        builder: (BuildContext context,
            AsyncSnapshot<List<Map<String, dynamic>>> data) {
          List<TableRow> allergies = [];
          allergies.add(const TableRow(children: [
            Text(
              "Allergy",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            )
          ]));
          data.data?.forEach((element) {
            allergies.add(TableRow(children: [Text(element["allergy"])]));
          });
          return Table(
            children: allergies,
          );
        });
  }
}
