// ignore_for_file: file_names

import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'helpers/db_helpers.dart';
import 'package:flutter/material.dart';

class AddProblem extends StatelessWidget {
  AddProblem({Key? key}) : super(key: key);

  Map<String, Object> problemData = <String, Object>{};
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    problemData["username"] = DBHelper.username;
    return Scaffold(
        appBar: AppBar(
          title: const Text('Add a Problem'),
        ),
        body: Column(
          children: [
            _buildForm(context),
            TextButton(
                onPressed: () {
                  DBHelper.insert("problems", problemData);
                },
                child: const Text("Add Problem"))
          ],
        ));
  }

  Form _buildForm(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          ElevatedButton(
              onPressed: () {
                DatePicker.showDatePicker(context,
                    showTitleActions: true,
                    minTime: DateTime(1980, 1, 1),
                    maxTime: DateTime(2020, 12, 31),
                    theme: const DatePickerTheme(
                        headerColor: Colors.orange,
                        backgroundColor: Colors.black,
                        itemStyle: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 18),
                        doneStyle:
                            TextStyle(color: Colors.white, fontSize: 16)),
                    onChanged: (date) {
                  problemData["date"] = date.toString();
                },
                    onConfirm: (date) {},
                    currentTime: DateTime.now(),
                    locale: LocaleType.en);
              },
              child: Text(
                problemData["date"].toString(),
                style: TextStyle(color: Colors.blue.shade50),
              )),
          DropdownButtonFormField<int>(
            items: <int>[1, 2, 3, 4, 5].map((int value) {
              return DropdownMenuItem<int>(
                value: value,
                child: Text(value.toString()),
              );
            }).toList(),
            onChanged: (value) => {problemData["scale"] = value.toString()},
            decoration: InputDecoration(
              hintText: 'Scale',
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(20.0)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              onChanged: (value) => {problemData["problem"] = value},
              validator: (value) {
                if (value == null) {
                  return 'Problem cannot be empty';
                }
                return null;
              },
              decoration: InputDecoration(
                labelText: 'Problem',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
