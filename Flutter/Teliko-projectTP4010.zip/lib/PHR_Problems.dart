// ignore_for_file: file_names

import 'package:syncfusion_flutter_charts/charts.dart';

import 'helpers/db_helpers.dart';
import 'package:flutter/material.dart';

class Problems extends StatelessWidget {
  const Problems({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text("Problems"),
            bottom: const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.list)),
                Tab(icon: Icon(Icons.auto_graph)),
              ],
            ),
          ),
          body: const TabBarView(children: [
            ListTab(),
            GraphTab(),
          ]),
        ));
  }
}

class ListTab extends StatelessWidget {
  const ListTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        ElevatedButton(
          onPressed: () {
            Navigator.pushNamed(context, '/PHR_addProblem');
          },
          child: const Text('Add a Problem'),
        ),
        getProblems(),
      ],
    );
  }

  Widget getProblems() {
    return FutureBuilder(
        future: DBHelper.getData('problems'),
        builder: (BuildContext context,
            AsyncSnapshot<List<Map<String, dynamic>>> data) {
          List<TableRow> problems = [];
          problems.add(const TableRow(children: [
            Text("Date",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            Text("Scale",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
            Text("Problem",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
          ]));
          data.data?.forEach((element) {
            problems.add(TableRow(children: [
              Text(element["date"]),
              Text(element["scale"].toString()),
              Text(element["problem"]),
            ]));
          });
          return Table(
            children: problems,
          );
        });
  }
}

class GraphTab extends StatelessWidget {
  const GraphTab({Key? key}) : super(key: key);

  FutureBuilder createProblemsChart(BuildContext context) {
    return FutureBuilder(
        future: DBHelper.getData('problems'),
        builder: (context, snapshot) {
          String myData = "";
          if (snapshot.hasData) {
            List<ProblemDataPoint> problemDataPoints = <ProblemDataPoint>[];
            for (Map<String, dynamic> i in snapshot.data) {
              problemDataPoints.add(ProblemDataPoint(i['date'], i['scale']));
            }
            return SfCartesianChart(
              primaryXAxis: CategoryAxis(),
              margin: const EdgeInsets.all(50),
              series: <ChartSeries>[
                ScatterSeries<ProblemDataPoint, String>(
                    dataSource: problemDataPoints,
                    xValueMapper: (ProblemDataPoint data, _) => data.date,
                    yValueMapper: (ProblemDataPoint data, _) => data.scale,
                    dataLabelSettings: const DataLabelSettings(isVisible: true),
                    enableTooltip: true)
              ],
            );
          }
          return Text(myData);
        });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[createProblemsChart(context)],
      ),
    );
  }
}

class ProblemDataPoint {
  ProblemDataPoint(this.date, this.scale);
  final String date;
  final num scale;
}
