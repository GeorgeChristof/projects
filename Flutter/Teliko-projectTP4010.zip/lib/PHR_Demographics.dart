// ignore_for_file: file_names
import 'package:flutter/material.dart';
import 'helpers/db_helpers.dart';

class Demographics extends StatelessWidget {
  const Demographics({Key? key}) : super(key: key);

  Future<List<Text>> getDemog() async {
    List<Text> people = [];
    Future<List<Map<String, dynamic>>> users = DBHelper.getData("users");
    await users.then((value) => {
          value.forEach((element) {
            people.add(Text(
                "${element['name']} ${element['surname']} ${element['weight']} ${element['email']}"));
          })
        });
    return people;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Demographics'),
      ),
      body: FutureBuilder<List<Text>>(
          future: getDemog(),
          builder: (BuildContext context, AsyncSnapshot<List<Text>> people) {
            if (people.hasData && people.data != null) {
              return ListView(children: (people.data as List<Text>));
            } else {
              return const Text('Null');
            }
          }),
    );
  }
}
