// ignore_for_file: file_names

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class Steps extends StatelessWidget {
  const Steps({ Key? key }) : super(key: key);
  
  FutureBuilder createStepsChart(BuildContext context){
    return FutureBuilder(
                future: DefaultAssetBundle.of(context).loadString('data_repo/response_calories_steps.json'),
                builder: (context, snapshot){
                  String myData = "";
                  if(snapshot.hasData){
                    var activityData = json.decode(snapshot.data!);
                    var numSteps = activityData['activities'][6]['steps'];
                    myData = numSteps.toString();
                    final List<ChartData> chartData = [
                        ChartData('Steps', numSteps, Colors.green),
                        ChartData('Remaining', 8000-numSteps, Colors.red),
                    ];
                    return SfCircularChart(
                      series: <CircularSeries>[ 
                  PieSeries<ChartData, String>(
                        dataSource: chartData, 
                        xValueMapper: (ChartData data, _) => data.title,
                        yValueMapper: (ChartData data, _) => data.steps, 
                        dataLabelSettings: const DataLabelSettings(isVisible: true), 
                        enableTooltip: true,
                        
                        radius: '80%'
                        )
                    ],
                    );
                  }
                  return Text(myData);
                }
              );
  } 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Steps Graph"),
      ),
      body: Center(
        child: createStepsChart(context),
      ),
    );
  }
}

class ChartData {
  ChartData(this.title, this.steps, this.color);
  final String title;
  final num steps;
  final Color color;
}