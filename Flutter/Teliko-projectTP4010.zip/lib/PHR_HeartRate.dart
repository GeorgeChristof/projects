// ignore_for_file: file_names
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class Heartrate extends StatelessWidget {
  const Heartrate({Key? key}) : super(key: key);

  FutureBuilder createHeartRateChart(BuildContext context) {
    return FutureBuilder(
        future: DefaultAssetBundle.of(context)
            .loadString('data_repo/heartrate.json'),
        builder: (context, snapshot) {
          String myData = "";
          if (snapshot.hasData) {
            List heartData = json.decode(snapshot.data!)["activities-heart"];
            List<HeartDataPoint> heartDataPoints = <HeartDataPoint>[];
            for (Map<String, dynamic> i in heartData) {
              heartDataPoints
                  .add(HeartDataPoint(i['dateTime'], i['heartRate']));
            }
            return SfCartesianChart(
              primaryXAxis: CategoryAxis(),
              margin: const EdgeInsets.all(50),
              series: <ChartSeries>[
                StackedLineSeries<HeartDataPoint, String>(
                    dataSource: heartDataPoints,
                    xValueMapper: (HeartDataPoint data, _) => data.date,
                    yValueMapper: (HeartDataPoint data, _) => data.rate,
                    dataLabelSettings: const DataLabelSettings(isVisible: true),
                    enableTooltip: true)
              ],
            );
          }
          return Text(myData);
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Heart Rate"),
      ),
      body: Center(
        child: createHeartRateChart(context),
      ),
    );
  }
}

class HeartDataPoint {
  HeartDataPoint(this.date, this.rate);
  final String date;
  final num rate;
}
