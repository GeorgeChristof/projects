// ignore_for_file: file_names

import 'helpers/db_helpers.dart';
import 'package:flutter/material.dart';

class AddAllergy extends StatelessWidget {
  AddAllergy({Key? key}) : super(key: key);

  Map<String, String> allergyData = <String, String>{};
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    allergyData["username"] = DBHelper.username;
    return Scaffold(
        appBar: AppBar(
          title: const Text('Add an Allergy'),
        ),
        body: Column(
          children: [
            _buildForm(),
            TextButton(
                onPressed: () {
                  DBHelper.insert("allergies", allergyData);
                },
                child: const Text("Add Allergy"))
          ],
        ));
  }

  Form _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              onChanged: (value) => {allergyData["allergy"] = value},
              validator: (value) {
                if (value == null) {
                  return 'Allergy cannot be empty';
                }
                return null;
              },
              decoration: InputDecoration(
                labelText: 'Allergy',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
