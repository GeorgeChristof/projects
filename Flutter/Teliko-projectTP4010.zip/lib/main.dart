import 'package:assignment3/PHR_Problems.dart';
import 'package:assignment3/PHR_addProblem.dart';
import 'package:path/path.dart';

import 'PHR_Allergies.dart';
import 'PHR_Demographics.dart';
import 'PHR_HeartRate.dart';
import 'PHR_Steps.dart';
import 'PHR_addAllergy.dart';
import 'homeScreen.dart';
import 'signUpScreen.dart';
import 'package:flutter/material.dart';
import './loginScreen.dart';


void main() {
  runApp(MaterialApp(
    initialRoute: '/loginScreen',
    routes: {
      '/loginScreen': (context) => LoginScr(),
      '/signUpScreen': (context) => SignUpScreen(),
      '/homeScreen': (context) => const HomeScreen(),
      '/PHR_Steps': (context) => const Steps(),
      '/PHR_HeartRate': (context) => const Heartrate(),
      '/PHR_Demographics': (context) => const Demographics(),
      '/PHR_Allergies': (context) => const Allergies(),
      '/PHR_addAllergy': (context) => AddAllergy(),
      '/PHR_Problems': (context) => const Problems(),
      '/PHR_addProblem': (context) => AddProblem(),
    },
  ));
}