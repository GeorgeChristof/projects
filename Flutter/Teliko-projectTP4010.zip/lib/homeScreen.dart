// ignore_for_file: file_names
import 'dart:convert';

import 'package:assignment3/helpers/db_helpers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  FutureBuilder createStepsChart(BuildContext context) {
    return FutureBuilder(
        future: DefaultAssetBundle.of(context)
            .loadString('data_repo/response_calories_steps.json'),
        builder: (context, snapshot) {
          String myData = "";
          if (snapshot.hasData) {
            var activityData = json.decode(snapshot.data!);
            var numSteps = activityData['activities'][6]['steps'];
            myData = numSteps.toString();
            final List<ChartData> chartData = [
              ChartData('Steps', numSteps, Colors.green),
              ChartData('Remaining', 8000 - numSteps, Colors.red),
            ];
            return SfCircularChart(
              margin: const EdgeInsets.all(50),
              series: <CircularSeries>[
                //επιλεγω τα στρογγυλα γραφηματα
                PieSeries<ChartData, String>(
                    dataSource: chartData,
                    xValueMapper: (ChartData data, _) => data.title,
                    yValueMapper: (ChartData data, _) => data.steps,
                    radius: '100%')
              ],
            );
          }
          return Text(myData);
        });
  }

  FutureBuilder createHeartRateChart(BuildContext context) {
    return FutureBuilder(
        future: DefaultAssetBundle.of(context)
            .loadString('data_repo/heartrate.json'),
        builder: (context, snapshot) {
          String myData = "";
          if (snapshot.hasData) {
            List heartData = json.decode(snapshot.data!)["activities-heart"];
            List<HeartDataPoint> heartDataPoints = <HeartDataPoint>[];
            for (Map<String, dynamic> i in heartData) {
              heartDataPoints
                  .add(HeartDataPoint(i['dateTime'], i['heartRate']));
            }
            return SfCartesianChart(
              primaryXAxis: CategoryAxis(),
              margin: const EdgeInsets.all(50),
              series: <ChartSeries>[
                StackedLineSeries<HeartDataPoint, String>(
                  dataSource: heartDataPoints,
                  xValueMapper: (HeartDataPoint data, _) => data.date,
                  yValueMapper: (HeartDataPoint data, _) => data.rate,
                )
              ],
            );
          }
          return Text(myData);
        });
  }

  FutureBuilder createProblemsChart(BuildContext context) {
    return FutureBuilder(
        future: DBHelper.getData('problems'),
        builder: (context, snapshot) {
          String myData = "";
          if (snapshot.hasData) {
            List<ProblemDataPoint> problemDataPoints = <ProblemDataPoint>[];
            for (Map<String, dynamic> i in snapshot.data) {
              problemDataPoints.add(ProblemDataPoint(i['date'], i['scale']));
            }
            return SfCartesianChart(
              primaryXAxis: CategoryAxis(),
              margin: const EdgeInsets.all(50),
              series: <ChartSeries>[
                ScatterSeries<ProblemDataPoint, String>(
                  dataSource: problemDataPoints,
                  xValueMapper: (ProblemDataPoint data, _) => data.date,
                  yValueMapper: (ProblemDataPoint data, _) => data.scale,
                )
              ],
            );
          }
          return Text(myData);
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        title: const Text("Personal Health Record"),
      ),
      body: StaggeredGrid.count(
        crossAxisCount: 4,
        mainAxisSpacing: 2,
        crossAxisSpacing: 2,
        children: [
          StaggeredGridTile.count(
              crossAxisCellCount: 2,
              mainAxisCellCount: 2.5,
              child: MyCard("Steps", createStepsChart(context), "/PHR_Steps")),
          StaggeredGridTile.count(
              crossAxisCellCount: 2,
              mainAxisCellCount: 1.5,
              child: MyCard("Demographics", const Icon(Icons.person),
                  "/PHR_Demographics")),
          StaggeredGridTile.count(
              crossAxisCellCount: 2,
              mainAxisCellCount: 2.5,
              child: MyCard(
                  "Problems", createProblemsChart(context), "/PHR_Problems")),
          StaggeredGridTile.count(
              crossAxisCellCount: 2,
              mainAxisCellCount: 1.5,
              child: MyCard("Allergies", const Icon(Icons.personal_injury),
                  "/PHR_Allergies")),
          StaggeredGridTile.count(
              crossAxisCellCount: 4,
              mainAxisCellCount: 2,
              child: MyCard("Heart Rate", createHeartRateChart(context),
                  "/PHR_HeartRate")),
        ],
      ),
      drawer: const WidgetDrawer(),
    );
  }
}

class MyCard extends StatelessWidget {
  String title = "";
  Widget widget = Text("");
  String route = "";

  MyCard(String cardText, Widget cardWidget, String routeT, {Key? key})
      : super(key: key) {
    title = cardText;
    widget = cardWidget;
    route = routeT;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Card(
        child: InkWell(
          splashColor: Colors.blue.withAlpha(30),
          onTap: () {
            Navigator.pushNamed(context, route);
          },
          child: SizedBox(
            width: 500,
            height: 500,
            child: SingleChildScrollView(
                child: Column(
              children: [
                Text(
                  title,
                  style: const TextStyle(fontSize: 25, color: Colors.blue),
                ),
                widget
              ],
            )),
          ),
        ),
      ),
    );
  }
}

class ChartData {
  ChartData(this.title, this.steps, this.color);
  final String title;
  final num steps;
  final Color color;
}

class HeartDataPoint {
  HeartDataPoint(this.date, this.rate);
  final String date;
  final num rate;
}

class ProblemDataPoint {
  ProblemDataPoint(this.date, this.scale);
  final String date;
  final num scale;
}

class WidgetDrawer extends StatelessWidget {
  const WidgetDrawer({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            padding: EdgeInsets.fromLTRB(25, 45, 5, 8),
            child: Text(
              'PHR',
              style: TextStyle(fontSize: 40),
            ),
          ),
          ListTile(
            title: const Text('Home'),
            onTap: () {},
          ),
          ListTile(
            title: const Text('Heartrate'),
            onTap: () {
              Navigator.pushNamed(context, '/PHR_HeartRate');
            },
          ),
          ListTile(
            title: const Text('Steps'),
            onTap: () {
              Navigator.pushNamed(context, '/PHR_Steps');
            },
          ),
          ListTile(
            title: const Text('Problems'),
            onTap: () {
              Navigator.pushNamed(context, '/PHR_Problems');
            },
          ),
          ListTile(
            title: const Text('Allergies'),
            onTap: () {
              Navigator.pushNamed(context, '/PHR_Allergies');
            },
          ),
          ListTile(
            title: const Text('Demographics'),
            onTap: () {
              Navigator.pushNamed(context, '/PHR_Demographics');
            },
          ),
        ],
      ),
    );
  }
}
