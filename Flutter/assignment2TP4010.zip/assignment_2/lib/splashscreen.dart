import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  var yourList = [
    "I am improving all time",
    "Listen to emotions but also evaluate",
    "Trying hard will get me what I want",
    "Each day is a new day. Try again"
  ];                                           //το κειμενο του splash screen
  int randomIndex = 0;                         //δημιουργει ενα τυχαιο αριθμο απο το length της λιστας

  @override
  void initState() {
    super.initState();
    randomIndex =
        Random().nextInt(yourList.length);    //πριν την build οριζουμε το στοιχειο
    Timer(const Duration(seconds: 5), () {    //μετα απο 5 δευτερολεπτα καλειται ο Navigator
      Navigator.pushNamed(
          context, '/home');                  // εδω χρησιμοποιουμε το named route που εχουμε δηλωσει στην main.dart
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
          decoration:const BoxDecoration(
            image: DecorationImage(image: AssetImage('assets/images/splash.jpg'), fit: BoxFit.cover),
          ),
      child: Center(
        child: Text(yourList[randomIndex],
            style: const TextStyle(
              fontSize: 45,
              color: Colors.red
            )),
      ),
    ));
  }
}
