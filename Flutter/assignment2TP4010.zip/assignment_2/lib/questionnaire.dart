import 'dart:convert';
import 'package:flutter/material.dart';

class questionnaire extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title:const Text("Questionnaire"),
          backgroundColor: Colors.black38,
        ),
        body: Container(
          child: Center(
            child: FutureBuilder(
                future: DefaultAssetBundle 
                    .of(context)
                    .loadString('data_repo/questionnaire.json'),
                builder: (context, snapshot) { //κραταει ενα snapshot της τωρινης καταστασης του future
                  // Decode the JSON
                  var newData = json.decode(snapshot.data.toString()); //το snapshot.data μας το δινει το flutter και παινρουμε τα δεδομενα της καταστασης του future εδω δηλαδη τα data του json αρχειου.
                  return ListView.builder(        // Χρησιμοποιουμε τον constructor builder γιατι δεν ξερουμε το πληθος των αντικειμενων
                    itemBuilder: (BuildContext context, int index) {
                      return question(newData[index]['questionText'],newData[index]['answers']);
                    },
                    itemCount: newData == null ? 0 : newData.length, //ελεγχος αν η τιμη ειναι null αλλιως δινουμε το πληθος των αντικειμενων της λιστας που θελουμε να γινουν build στο itemCount
                  );
                }),
          ),
        ));
  }
  Widget question(String question, var answers) {
    return Visibility(
      child: Padding(
      padding:const EdgeInsets.all(10.0),
        child: Container(
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: 10.0), //συμμετρικη αποσταση στον καθετο αξονα
                  child: Text('Over the last 2 weeks, how often have you been bothered by any of the following problems?')
                ),
                Center(
                  child: Text(
                    question, //δυναμικο κειμενο
                    style:const TextStyle(
                        fontSize: 24,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Center(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.all(20),
                      backgroundColor: Colors.grey
                    ),
                    onPressed: () => {},
                    child: Text(
                    answers[0], //δυναμικο κειμενο
                    style:const TextStyle(
                        fontSize: 24,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Center(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.all(20),
                      backgroundColor: Colors.grey
                    ),
                    onPressed: () => {},
                    child: Text(
                    answers[1],
                    style:const TextStyle(
                        fontSize: 24,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                ),
                Center(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.all(20),
                      backgroundColor: Colors.grey
                    ),
                    onPressed: () => {},
                    child: Text(
                    answers[2],
                    style:const TextStyle(
                        fontSize: 24,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                ),
                Center(
                  child:TextButton(
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.all(20),
                      backgroundColor: Colors.grey
                    ),
                    onPressed: () => {},
                    child: Text(
                    answers[3],
                    style:const TextStyle(
                        fontSize: 24,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                ),
              ],
            ),
          ),
     ) );
  }
}

