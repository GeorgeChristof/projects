import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';

class suggestions extends StatefulWidget {
  @override
  _suggestionsState createState() => _suggestionsState();
}

class _suggestionsState extends State<suggestions> {
  @override
  var text = ['What is depression?', 'Why is this a problem?', 'When is depression caused by stress?', 'Why does it seem that depression is caused by stress?'];
  var shortDescription = [
    'Some of these comments may be well-intentioned but they show a lack of understanding of the nature of depression...',
    'The misunderstanding occurs because just about everyone has experienced sadness or “feeling down.”...',
    'Although the above conditions appear to be biological conditions that are caused by genetic predispositions...',
    'The fact is that the depressive disorders, as is true of most of the physical disorders, are reactive to stress...'
  ];
  List<String> images = [
    "assets/images/article1.jpg",
    "assets/images/article2.jpg",
    "assets/images/article3.jpg",
    "assets/images/article4.jpg"
  ];

  Widget customcard(String text, String imagepath, String shortDescription, String route) {
    return Padding(
      padding:const EdgeInsets.all(10.0),
      child: InkWell( onTap: () {
        Navigator.of(context).pushNamed(route);
        },
        child: Card(
          elevation: 10.0,

          child: Wrap(
            children: [
              Image.network(imagepath),
              ListTile(
                title: Text(text),
                subtitle: Text(shortDescription),
              ),
            ],
          ),
        ),
      ),
    );
  }
Widget build(BuildContext context) {
    const title = 'Suggestions';
    return Scaffold(
      appBar: AppBar(
        title:const Text(title),
        backgroundColor: Colors.black38,
      ),
      body: Container(
        margin: const EdgeInsets.symmetric(vertical: 20.0),
        height: 400.0,
        width: 500,
        child: ScrollConfiguration(
                    behavior: ScrollConfiguration.of(context).copyWith( //οριζοντια κυλιση
                        dragDevices: {
                          PointerDeviceKind.touch,
                          PointerDeviceKind.mouse
                        }),
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
         
          scrollDirection: Axis.horizontal,
          children: <Widget>[
            Container(
              width: 160,
              child: customcard(
                  text[0], images[0], shortDescription[0], '/article1'),
            ),
            Container(
              width: 160,
              child: customcard(
                  text[1], images[1], shortDescription[1], '/article2'),
            ),
            Container(
              width: 160,
              child: customcard(
                  text[2], images[2], shortDescription[2], '/article3'),
            ),
            Container(
              width: 160,
              child: customcard(
                  text[3], images[3], shortDescription[3], '/article4'),
            ),
          ],
        ),
      ),
    ));
  }
}