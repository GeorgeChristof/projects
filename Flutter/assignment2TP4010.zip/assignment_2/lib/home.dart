import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var listImages = [
    //η λιστα με τις εικονες που θα εμφανισουμε
    'assets/images/quest.jpg',
    'assets/images/sugg.jpg'
  ];

  Widget customcard(String langname, String imagepath, String route) {
    return Padding(
      padding:const EdgeInsets.all(10.0),
      child: InkWell(
        onTap: () {
          Navigator.of(context).pushNamed(route);
        },
        child: Card(
          color: Colors.black38,
          elevation: 10.0, 
		  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25),),//στρογγυλοποιηση γωνιών της κάρτας
          child: Container(
            child: Column(
              children: [
                Padding(
                  padding:const EdgeInsets.symmetric(
                      vertical: 10.0), //συμμετρικη αποσταση στον καθετο αξονα
                  child: Material(
                    //χρησιμοποιουμε το material για την σκιαση κτλ
                    elevation: 5.0, //σκια
                    borderRadius: BorderRadius.circular(100), //για να γινει στρογγυλο το container που περιεχει την εικονα
                    child: Container(
                      height: 250, 
                      width: 250,
                      child: ClipOval(          //κοβει την εικονα και την κανει στρογγυλη

                        child: Image(
                          fit: BoxFit.contain, //να γεμιζει η εικονα τον χωρο
                          image: AssetImage(imagepath), //δυναμικο path εικονας
                        ),
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Text(
                    langname, //δυναμικο κειμενο
                    style:const TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:const Text("Depression CBT"),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.black38,
      ),
      body: ListView(
        children: [
          customcard("Suggestions", listImages[1],'/suggestions'), //περναμε τιτλο και εικονα απο την λιστα
          customcard("Questionnaire", listImages[0], '/questionnaire')
        ],
      ),
    );
  }
}
