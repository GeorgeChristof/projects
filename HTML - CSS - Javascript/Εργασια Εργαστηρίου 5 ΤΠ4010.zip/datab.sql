drop database if exists users;
create database users;
use users;

create table memb(  mid int NOT NULL auto_increment,
					username varchar(20) NOT NULL,
                    passwrd varchar(30) NOT NULL,
                    firstname varchar(30) NOT NULL,
                    lastname varchar(30) NOT NULL,
                    primary key (mid));
                    
-- insert into memb (username,passwrd,firstname,lastname) values   ("takis","123","Takoulis","Takoglou"),
-- 																   ("maria","567","Mairi","Mariakaki");
                        
-- SELECT * FROM memb;