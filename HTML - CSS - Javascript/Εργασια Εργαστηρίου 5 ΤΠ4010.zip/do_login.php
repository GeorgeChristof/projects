<?php 
$username = $_REQUEST["user"];
$userpass = $_REQUEST["pwd"];

$dbname = "users";
$dbuser = "phproot";
$passwd = "12345678";

$dbhost = "localhost";
$options = [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ];

$dsn = "mysql:host={$dbhost};dbname={$dbname};charset=utf8mb4";
$pdo = new PDO($dsn, $dbuser, $passwd, $options);
$user = $pdo->prepare("SELECT * FROM memb where username = :username ORDER BY mid DESC LIMIT 1;");
$user->execute(['username'=> $username]);
$userdata = $user-> fetch();

if ($userdata) {
	if ($userdata[2] == $userpass) {
		echo "You have now logged in";
	}	else {
		echo "Wrong password";
}	}	
else {
		echo "Wrong username";
}

?>