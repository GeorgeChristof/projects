<?php 
$username = $_REQUEST["user"];
$userpass = $_REQUEST["pwd"];
$userfname = $_REQUEST["name"];
$userlname = $_REQUEST["surname"];

$dbname = "users";
$dbuser = "phproot";
$passwd = "12345678";

$dbhost = "localhost";
$options = [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ];

$dsn = "mysql:host={$dbhost};dbname={$dbname};charset=utf8mb4";
$pdo = new PDO($dsn, $dbuser, $passwd, $options);
$user = $pdo->prepare("insert into memb (username,passwrd,firstname,lastname) values   (:username,:password,:fname,:lname);");
$res= $user->execute(['username'=> $username,'password'=> $userpass, 'fname'=> $userfname, 'lname'=> $userlname]);
if ($res) {
	echo "User data are saved, you can now login";
}

?>