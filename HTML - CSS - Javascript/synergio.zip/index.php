<?php include("header.php"); ?>

<div >

  <div class="maincontent" >
    
     <img src="/photos/main.jpg" class="mainphoto" >
    

    <div class="maintext">
      <h1>Συνεργείο του Μπάμπη</h1><br>
      <h5>Υπευθυνότητα από το 1987</h5>
      <p>Lorem ipsum dolor sit amet, equidem abhorreant id cum, an vel splendide efficiendi. Sit ut velit tantas singulis. No semper invidunt per, nam id agam phaedrum. Quo viris offendit no. Pri et erant aliquando torquatos, id has albucius concludaturque. Brute option copiosae ad est, per aliquam molestiae te, duis dolores inciderint sit ne.</p>
      <p>Eum imperdiet consetetur ut, per meis vidit id, audire invenire suavitate ne has. Expetendis honestatis cum at, ad nam semper persius inermis. Eos ei persius legendos elaboraret. Eum ea debitis referrentur, cu debet bonorum duo, oratio primis salutandi cum ad.</p>
    </div>
  </div>

</div>

</html>
    <?php include("footer.php"); ?>