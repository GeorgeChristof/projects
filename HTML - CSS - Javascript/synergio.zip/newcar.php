<?php include("header.php"); ?>
      <div>
        <div>
            <h1>Προσθήκη αυτοκινήτου</h1><br>
            <p>Εδώ μπορείτε να προσθέσετε ένα νεο αυτοκίνητο στην σελίδα </p>
            <p>Συμπληρώστε τον Αριθμό Κυκλοφορίας και το μοντέλο:</p>
        </div>

      <form method="POST" action="doaddcar.php">    
    


    

    
        <div>
            <label for="exampleFormControlInput1" class="form-label">Αριθμός Κυκλοφορίας</label>
            <input type="Text" class="form-control" id="akik" name = "akik" placeholder="Αριθμ.Κυκλοφ.">
        </div>
        <div>
        <label for="exampleFormControlTextarea1" class="form-label">Μοντέλο</label>
        <input type = "text" class="form-control" id="model" name = "model"></textarea>
        </div>           
        <div>
            <div>
                <button type="submit">Καταχώρηση</button>
            </div>
        </div>
    </form>
      
    </div>


<?php include("footer.php"); ?>