<?php include("header.php"); ?>
<script>
    const photos = [];
    var currentphoto = 0;
    function checkphoto(photoid){
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var photo = document.createElement("img");
                photo.src = "/photos/photo" + photoid + ".jpg";
                photos[photoid] = photo;
                document.getElementById("photos").appendChild(photo);
                checkphoto(photoid+1);
                showphoto(0);
            }
        };
        xhttp.open("GET", "/photos/photo" + photoid + ".jpg", true);
        xhttp.send();
    }    

    function showphoto(photoid){
        photos.forEach( (photo) => {
            photo.style.display = "none";
        });
        photos[photoid].style.display = "block";
    }

    function prevphoto(){
        currentphoto-=1;
        if(currentphoto < 0)
            currentphoto = photos.length - 1;
        showphoto(currentphoto);
    }

    function nextphoto(){
        currentphoto+=1;
        if(currentphoto >= photos.length)
            currentphoto = 0;
        showphoto(currentphoto);
    }

    function loadphotos(){
        
        checkphoto(0);
    }
    document.addEventListener("DOMContentLoaded",loadphotos);
    
</script>

    <div>
        <h1>Φωτογραφίες</h1><br>
        <p>Παρακάτω, θα δείτε ενα μικρό δείγμα της δουλειάς μας και της εξαιρετικής αξιοπιστίας που παρέχουμε.</p>
    </div>

<div id = "content">    
    <div id = "photos" >
        <button type = "button" onclick = "prevphoto()">Previous </button>
        <button type = "button" onclick = "nextphoto()">Next </button>
    </div>
</div>
<?php include("footer.php"); ?>