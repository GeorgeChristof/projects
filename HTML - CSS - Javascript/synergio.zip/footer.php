<!-- Footer -->
<footer>
  <p>Made by George Christoforakis</p>
</footer>

</body>
</html>