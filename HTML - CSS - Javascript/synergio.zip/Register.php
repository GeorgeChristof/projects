<?php include("header.php"); ?>
      <div>
      <form method="POST" action="do_register.php">    
        <div>
            <label for="exampleFormControlInput1" class="form-label">Όνομα</label>
            <input type="Text" class="form-control" id="name" name = "name" >
        </div>
        <div>
        <label for="exampleFormControlTextarea1" class="form-label">Επώνυμο</label>
        <textarea class="form-control" id="surname" name = "surname" rows="3"></textarea>
        </div>                  
        <div>
        <label for="exampleFormControlTextarea1" class="form-label">e-mail</label>
        <textarea class="form-control" id="email" name = "email" rows="3"></textarea>
        </div>   
        <div>
        <label for="exampleFormControlTextarea1" class="form-label">Τηλέφωνο</label>
        <textarea class="form-control" id="phone" name = "phone" rows="3"></textarea>
        </div>
        <div>
        <label for="exampleFormControlTextarea1" class="form-label">Κωδικός</label>
        <textarea class="form-control" id="pwd" name = "pwd" rows="3"></textarea>
        </div>        
        <div>
            <div>
                <button type="submit">Εγγραφή</button>
            </div>
        </div>
    </form>
      
    </div>
<?php include("footer.php"); ?>