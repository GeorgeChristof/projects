<?php include("header.php"); ?>
      
      <div>
      <?php
                         
        require_once "database.php";
        $pdo = getconn();
        $announcements = $pdo->query("SELECT * FROM announcements LEFT JOIN users ON announcements.Users_idUsers = users.idUsers ;");
        
        while($announcement = $announcements-> fetch())
        {    
            if ($announcement )
            {
      ?>
      <div class = "center-content">
      
            <h1><?php echo $announcement[1] ?> </h1>
            <p><?php echo $announcement[2] ?></p>
            <h3 class = "from">Από <?php echo $announcement[5] . " " . $announcement[6] ?> </h3>
            
            <hr class = "seperate"> 
      </div>
      <?php
            }
        }
        
      ?>
      
    </div>
<?php include("footer.php"); ?>