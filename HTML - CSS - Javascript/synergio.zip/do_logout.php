<?php 
    session_start(); 
    if (array_key_exists('isloggedin',$_SESSION)) 
    {
        $_SESSION['isloggedin'] = false;
        $_SESSION['userid'] = 0;
    }    
    $url = '/';
    header('Location: ' . $url, true, 307);
    die();
    
?> 