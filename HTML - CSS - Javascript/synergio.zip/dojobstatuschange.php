<?php 
$newstatus = $_REQUEST["newstatus"];
$jobid = $_REQUEST["jobid"];

require_once "database.php";
$pdo = getconn();
$user = $pdo->prepare("UPDATE `jobs` SET `Jobstatus` = :newstatus WHERE (`idJobs` = :jobid);;");
$res= $user->execute(['newstatus'=> $newstatus,'jobid'=> $jobid]);
if ($res) {
	echo "Car job data is saved";
	$url = '/modifyjob.php';
		header('Location: ' . $url, true, 307);
		die();
}

?>