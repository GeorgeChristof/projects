<?php 
session_start();
$sender = $_REQUEST["sender"];
$subject = $_REQUEST["subject"];
$message = $_REQUEST["message"];

require_once "database.php";
$pdo = getconn();
$user = $pdo->prepare("INSERT INTO `messages` (`Sender`, `Subject`, `Message`) VALUES ( :sender , :subject , :message );");
$res= $user->execute(['sender'=> $sender,'subject'=> $subject, 'message'=> $message]);
if ($res) {
	header('HTTP/1.1 200 OK');
}else{
	header(header("HTTP/1.1 404 Not Found"));
}

?>