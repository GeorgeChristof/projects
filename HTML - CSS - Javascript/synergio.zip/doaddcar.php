<?php 
session_start();
$akik = $_REQUEST["akik"];
$model = $_REQUEST["model"];
$uid = $_SESSION["userid"];

require_once "database.php";
$pdo = getconn();
$car = $pdo->prepare("INSERT INTO `cars` ( `Akik`, `Model` , `idUsers`) values (:akik, :model, :uid);");
$res= $car->execute(['akik'=> $akik,'model'=> $model, 'uid'=> $uid]);
if ($res) {
	echo "Your car has been added!";
}

?>