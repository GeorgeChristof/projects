<?php 
    function getconn(){
        $dbname = "synergio";
        $dbuser = "root";
        $passwd = "1234";

        $dbhost = "localhost";
        $options = [ PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ];

        $dsn = "mysql:host={$dbhost};dbname={$dbname};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbuser, $passwd, $options);
        return $pdo;
    }
?>