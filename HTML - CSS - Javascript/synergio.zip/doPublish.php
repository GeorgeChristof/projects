<?php 
session_start();
$title = $_REQUEST["title"];
$text = $_REQUEST["text"];
$uid = $_SESSION["userid"];

require_once "database.php";
$pdo = getconn();
$user = $pdo->prepare("INSERT INTO `announcements` ( `Title`, `Text`, `Users_idUsers`) VALUES   (:title , :text , :userid );");
$res= $user->execute(['title'=> $title,'text'=> $text, 'userid'=> $uid]);
if ($res) {
	$url = '/';
	header('Location: ' . $url, true, 307);
	die();
}

?>