<?php include("header.php"); ?>
      <div>
      <?php
                         
        require_once "database.php";
        $pdo = getconn();        
        $messages = $pdo->query("SELECT * FROM messages ;");
        
        while($message = $messages-> fetch())
        {    
            if ($message )
            {
      ?>
            
            <div class="center-content">

                  <h1><?php echo $message[2] ?> </h1>
                  <p><?php echo $message[3] ?></p>
                  <h3 class = "from">Από <?php echo $message[1] ?> </h3>
                  <hr class = "seperate"> 
                  
            </div>
      <?php
            }
        }
        
      ?>
      
    </div>
<?php include("footer.php"); ?>