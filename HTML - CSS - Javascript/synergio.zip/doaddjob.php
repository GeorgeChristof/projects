<?php 
session_start();
$jobdesc = $_REQUEST["jobdesc"];
$carid = $_REQUEST["carid"];

require_once "database.php";
$pdo = getconn();
$car = $pdo->prepare("INSERT INTO `jobs` ( `Jobdesc`, `Cars_idCars` , `Jobstatus`) values (:jobdesc, :carid, 0);");
$res= $car->execute(['jobdesc'=> $jobdesc,'carid'=> $carid ]);
if ($res) {
	echo "Your job has been added!";
}

?>