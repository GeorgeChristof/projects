<?php 
    session_start(); 
    $isloggedin = false;
    $uid = -1;
    if (array_key_exists('isloggedin',$_SESSION)) 
    {
        $isloggedin = $_SESSION['isloggedin'] ;
        $uid = $_SESSION['userid'] ;
    }    
    
?> 
<html>
<title>Συνεργείο αυτοκινήτων</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="/css/site.css">
<style>
body {font-family: "Arial", sans-serif;}

</style>
<body>

<!-- Navbar (sit on top) -->
<div >
  <div class="navbar" >
    <img style = "height: 100px; float: left;" src = "/photos/Logo.png"> </img>
    <a href="/" class="navbutton">Συνεργείο</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    
      <a href="/" class="navbutton">Αρχική Σελίδα</a>
      <a href="/photos.php" class="navbutton">Φωτογραφίες</a>
      <a href="/announcements.php" class="navbutton">Ανακοινώσεις</a>
      <a href="/newmessage.php" class="navbutton">Φόρμα Επικοινωνίας</a>
      <?php 
            if ($isloggedin == false)
            { 
                ?>
      
      <a href="/Register.php" class="navbutton">Εγγραφή Χρήστη</a>
      <a href="/login.php" class="navbutton">Είσοδος Χρήστη</a>
      <?php }
            else
             {
                ?>  
      <a href="/newcar.php" class="navbutton">Προσθήκη αυτοκινήτου</a>
      <?php 
                    if($uid == 4)
                    {
                      ?>
      <a href="/newjob.php" class="navbutton">Προσθήκη εργασίας</a>
      <a href="/modifyjob.php" class="navbutton">Διαχείρηση εργασίας</a>
      <a href="/newAnnouncement.php" class="navbutton">Νεα Ανακοίνωση</a>
      <a href="/messages.php" class="navbutton">Προβολή Μηνυμάτων</a>
      <?php } ?>
      <a href="/do_logout.php" class="navbutton">Αποσύνδεση Χρήστη</a>
      <?php 
              }  ?> 
    
  </div>
</div>

<!-- Header -->
<header id="home">
  
  
</header>

<div style = "min-height: 50px">

</div>