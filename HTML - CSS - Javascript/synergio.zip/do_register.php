<?php 
$userfname = $_REQUEST["name"];
$userlname = $_REQUEST["surname"];
$useremail = $_REQUEST["email"];
$userphone = $_REQUEST["phone"];
$userpass = $_REQUEST["pwd"];

require_once "database.php";
$pdo = getconn();
$user = $pdo->prepare("INSERT INTO `users` ( `FName`, `LName`, `email`, `Phone`, `password`) values (:fname, :lname, :email, :phone, :pwd);");
$res= $user->execute(['fname'=> $userfname,'lname'=> $userlname, 'email'=> $useremail, 'phone'=> $userphone, 'pwd'=> $userpass]);
if ($res) {
	$url = '/';
	header('Location: ' . $url, true, 307);	
	die();
}

?>