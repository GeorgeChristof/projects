<?php include("header.php"); ?>
      <div>
      <form method="POST" action="do_login.php">
        <div>
            <label for="inputEmail" class="form-label">Email</label>
            <div>
                <input class="form-control" id="inputEmail" placeholder="Email" name="email">
            </div>
        </div>
        <div>
            <label for="inputPassword" class="form-label">Password</label>
            <div>
                <input type="password" class="form-control" id="inputPassword" placeholder="Password" name="pwd">
            </div>
        </div>        
        <div>
            <div>
                <button type="submit">Sign in</button>
            </div>
        </div>
    </form>
    </div>
    <?php include("footer.php"); ?>