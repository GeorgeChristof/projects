<?php include("header.php"); ?>
      
      <div >

        <div>
            <h1>Προσθήκη εργασίας</h1><br>
            <p>Εδώ μπορείτε να επιλέξετε εργασία για ένα ηδη καταχωριμένο όχημα</p>
            <p>Ενναλακτικά προσθέστε αυτοκίνητο, και μετά εργασία</p>
            <p>Συμπληρώστε τα παρακάτω: </p>
        </div>


      <form method="POST" action="doaddjob.php">    
      <?php
                         
        require_once "database.php";
        $pdo = getconn();
        $cars = $pdo->query("SELECT * FROM cars ;");
    ?>
        <label for="cars">Επέλεξε Όχημα: </label>

        <select name="carid" id="carid">
    
    <?php
        while($car = $cars-> fetch())
        {    
            if ($car )
            {
    ?>
        
        <option value = "<?php echo $car[0] ?>" ><?php echo $car[2]. " (" . $car[1] . " )" ?> </option>
        
        
      <?php
            }
        }
        
      ?>
    </select> 


    


    
        <div>
            <label for="exampleFormControlInput1" class="form-label">Περιγραφή εργασίας</label>
            <input type="Text" class="form-control" id="jobdesc" name = "jobdesc" >
        </div>
        <div>
            <div>
                <button type="submit">Καταχώρηση</button>
            </div>
        </div>
    </form>
      
    </div>

<?php include("footer.php"); ?>