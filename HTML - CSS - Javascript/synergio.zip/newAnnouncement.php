<?php include("header.php"); ?>
      <div>
      <form method="POST" action="doPublish.php">    
        <div>
            <label for="exampleFormControlInput1" class="form-label">Τίτλος Ανακοίνωσης</label>
            <input type="Text" maxlength = "40" class="form-control" id="title" name = "title" placeholder="Τίτλος">
        </div>
<div>
  <label for="exampleFormControlTextarea1" class="form-label">Κείμενο Ανακοίνωσης</label>
  <textarea class="form-control" maxlength = "400" id="text" name = "text" rows="3"></textarea>
</div>           
        <div>
            <div>
                <button type="submit">Δημοσίευση</button>
            </div>
        </div>
    </form>
      
    </div>
<?php include("footer.php"); ?>