<?php 

session_start(); 
$useremail = $_REQUEST["email"];
$userpass = $_REQUEST["pwd"];

require_once "database.php";
$pdo = getconn();
$user = $pdo->prepare("SELECT * FROM users where email = :email ORDER BY idUsers DESC LIMIT 1;");
$user->execute(['email'=> $useremail]);
$userdata = $user-> fetch();

if ($userdata) {
	if ($userdata[5] == $userpass) {
		//echo "You have now logged in";
		$_SESSION['isloggedin'] = true;
		$_SESSION['userid'] = $userdata[0];
		
		$url = '/';
		header('Location: ' . $url, true, 307);
		die();

	}	else {
		echo "Wrong password";
}	}	
else {
		echo "Wrong username";
}

?>