<?php include("header.php"); ?>

<script>
    function selectedjob(){
        var job = document.getElementById("jobid");
        var selected = job.options[job.selectedIndex];
        var oldstatus = document.getElementById("oldstatus");
        
        switch(selected.getAttribute("data-status")){
            case "0" : 
                oldstatus.innerHTML = "Καταχωρημένη";
                break;
            case "1" :
                oldstatus.innerHTML = "Σε εξέλιξη";
                break;
            case "2" :
                oldstatus.innerHTML = "Ολοκληρώθηκε";
                break;
            default : oldstatus.innerHTML = "Σφάλμα.";
        }
        
    }

    
    
</script>

    <div class="center-content" style = "display: block; width: 50%; text-align: center;">
      <h2>Μετάβαση εργασίας</h2>

      <form method="POST" action="/dojobstatuschange.php">    

      <?php
        require_once "database.php";
        $pdo = getconn();

        $jobs = $pdo->query("SELECT * FROM jobs LEFT JOIN cars ON jobs.Cars_idCars = cars.idCars;");
    ?>
        <label for="jobid" class = "form-label">Επέλεξε Εργασία: </label>

        <select name="jobid" id="jobid" size = "5" onchange = "selectedjob()">
        <label>Προς </label>
    <?php
        while($job = $jobs-> fetch())
        {    
            if ($job )
            {
    ?>
        
        <option data-status= "<?php echo $job[3] ?>" value = "<?php echo $job[0] ?>" ><?php echo $job[1]. " (" . $job[5] . " )" ?> </option>
        
        
      <?php
            }
        }
        
      ?>
    </select> 
      
      
      <?php
                         
        require_once "database.php";
        $pdo = getconn();
        $cars = $pdo->query("SELECT * FROM cars ;");
    ?>
        

   

    
        <h2 class = "form-label">Από </h2>
        <h3 id = "oldstatus">(Επιλέξτε εργασία)</h3> 
    
        <h2 class = "form-label">Προς </h2>
        <div class = "radio-toolbar">
            <input id = "newstatus" type = "radio" name = "newstatus" value = "0"></option>
            <label for = "newstatus">Καταχωρημένη</label>
            <input type = "radio" name = "newstatus" value = "1"></option>
            <label for = "newstatus">Σε εξέλιξη</label>
            <input type = "radio" name = "newstatus" value = "2"></option>
            <label for = "newstatus">Ολοκληρώθηκε</label>
        </div>
        <div>
            <div>
                <button class="form-control" type="submit" >Καταχώρηση</button>
            </div>
        </div>
    </form>
      
    </div>

<?php include("footer.php"); ?>