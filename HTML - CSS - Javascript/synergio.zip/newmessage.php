<?php include("header.php"); ?>

    <script>
        function sendmessage(){
            var sendform = document.getElementById("sendform");
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("sent").style.display = "block";
                    document.getElementById("sentbtn").style.display = "none";
                }
            };
            xhttp.open("POST", "/domessage.php", true);
            xhttp.send(new FormData(sendform));            
            return false;
        }           
    </script>
    
    <div>
        <h1>Επικοινωνία</h1><br>
        <p>Παρέχουμε όλες τις υπηρεσίες που χρειάζεται το αυτοκίνητο σας, με ασφάλεια, συνέπεια και υπευθυνότητα, σε πολύ προσιτές τιμές.</p>
        <p>Μπορείτε επίσης να επικοινωνήσεται στο 210-0000000 ή να μας επισκεφτείτε στην οδό Σάκη Ρουβά 17, Χαλάνδρι, Αθήνα Τ.Κ. 82612</p>
        <p>Ενναλακτικά επικοινωνίστε μαζί μας από την παρακάτω φόρμα: </p>
    </div>

      <div class="center-content" style = "display: block; width: 50%; text-align: center;">
      <form method="POST" id = "sendform" onsubmit = "return sendmessage()">    
        <div>
            <label for="subject" class="form-label">Θέμα Μηνύματος</label>
            <input type="Text" class="form-control" id="subject" name = "subject" placeholder="Θέμα">
        </div>
        <div>
            <label for="sender" class="form-label">Αποστολέας</label>
            <input type="Text" class="form-control" id="sender" name = "sender" placeholder="Αποστολέας">
        </div>
<div>
  <label for="exampleFormControlTextarea1" class="form-label">Κείμενο Μηνύματος</label>
  <textarea class="form-control" id="message" name = "message" rows="3"></textarea>
</div>           
        <div>
            <div>
                <button type="submit" style = "margin: 10px" id = "sentbtn" >Αποστολή</button>
            </div>
            <h1 style = "display: none" id = "sent" >Μήνυμα Απεστάλη </h1>
        </div>
    </form>
      
    </div>



<?php include("footer.php"); ?>